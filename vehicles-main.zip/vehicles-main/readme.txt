################### DB Detail ###################
DB Name: test
Username: root
Password: 


######################## Test User ################
username: fahad
password: 123